
(function($) {
    "use strict"

    new quixSettings({
        sidebarStyle: "full",
        navheaderBg: "color_2",
        sidebarBg: "color_2",
        headerPosition: "fixed",
        version: "dark",
        // layout: "horizontal"

    });


})(jQuery);